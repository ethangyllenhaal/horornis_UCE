#!/bin/bash
fsc26 -t large2small.tpl -n 100000 -e large2small.est -M -L 50 -q -c 6 -multiSFS
cat large2small/*.bestlhoods >> large2small.txt
for i in $(seq 49)
do
	fsc26 -t large2small.tpl -n 100000 -e large2small.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p large2small/*.bestlhoods >> large2small.txt
done

