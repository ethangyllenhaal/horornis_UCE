#!/bin/bash
cd 13noC2B
sh noC2B.sh
cd ..
cd 14noR2B
sh noR2B.sh
cd ..
cd 15noB2C
sh noB2C.sh
cd ..
cd 16noF2C
sh noF2C.sh
cd ..
cd 17noSmall2Large
sh noSmall2Large.sh
cd ..
cd 18top3
sh top3.sh
