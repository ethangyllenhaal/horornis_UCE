#!/bin/bash
fsc26 -t top3.tpl -n 100000 -e top3.est -M -L 50 -q -c 6 -multiSFS
cat top3/*.bestlhoods >> top3.txt
for i in $(seq 49)
do
	fsc26 -t top3.tpl -n 100000 -e top3.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p top3/*.bestlhoods >> top3.txt
done

