#!/bin/bash
fsc26 -t noC2B.tpl -n 100000 -e noC2B.est -M -L 50 -q -c 6 -multiSFS
cat noC2B/*.bestlhoods >> noC2B.txt
for i in $(seq 49)
do
	fsc26 -t noC2B.tpl -n 100000 -e noC2B.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p noC2B/*.bestlhoods >> noC2B.txt
done

