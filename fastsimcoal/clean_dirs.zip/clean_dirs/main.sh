#!/bin/bash
cd 8mix_even
sh mix_even.sh
cd ..
cd 9mix_uneven
sh mix_uneven.sh
cd ..
cd 10large2small
sh large2small.sh
cd ..
cd 11all6
sh all6.sh
cd ..
cd 12nohist
sh nohist.sh
