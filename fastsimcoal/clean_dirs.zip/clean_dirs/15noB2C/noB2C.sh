#!/bin/bash
fsc26 -t noB2C.tpl -n 100000 -e noB2C.est -M -L 50 -q -c 6 -multiSFS
cat noB2C/*.bestlhoods >> noB2C.txt
for i in $(seq 49)
do
	fsc26 -t noB2C.tpl -n 100000 -e noB2C.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p noB2C/*.bestlhoods >> noB2C.txt
done

