#!/bin/bash
fsc26 -t Nmig_even.tpl -n 100000 -e Nmig_even.est -M -L 50 -q -c 6 -multiSFS
cat Nmig_even/*.bestlhoods >> Nmig_even.txt
for i in $(seq 49)
do
	fsc26 -t Nmig_even.tpl -n 100000 -e Nmig_even.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p Nmig_even/*.bestlhoods >> Nmig_even.txt
done

