#!/bin/bash
fsc26 -t Nmig_uneven.tpl -n 100000 -e Nmig_uneven.est -M -L 50 -q -c 6 -multiSFS
cat Nmig_uneven/*.bestlhoods >> Nmig_uneven.txt
for i in $(seq 49)
do
	fsc26 -t Nmig_uneven.tpl -n 100000 -e Nmig_uneven.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p Nmig_uneven/*.bestlhoods >> Nmig_uneven.txt
done

