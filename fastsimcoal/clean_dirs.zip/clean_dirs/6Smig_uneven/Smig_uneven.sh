#!/bin/bash
fsc26 -t Smig_uneven.tpl -n 100000 -e Smig_uneven.est -M -L 50 -q -c 6 -multiSFS
cat Smig_uneven/*.bestlhoods >> Smig_uneven.txt
for i in $(seq 49)
do
	fsc26 -t Smig_uneven.tpl -n 100000 -e Smig_uneven.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p Smig_uneven/*.bestlhoods >> Smig_uneven.txt
done

