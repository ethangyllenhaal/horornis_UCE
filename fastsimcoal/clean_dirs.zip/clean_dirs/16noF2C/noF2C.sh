#!/bin/bash
fsc26 -t noF2C.tpl -n 100000 -e noF2C.est -M -L 50 -q -c 6 -multiSFS
cat noF2C/*.bestlhoods >> noF2C.txt
for i in $(seq 49)
do
	fsc26 -t noF2C.tpl -n 100000 -e noF2C.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p noF2C/*.bestlhoods >> noF2C.txt
done

