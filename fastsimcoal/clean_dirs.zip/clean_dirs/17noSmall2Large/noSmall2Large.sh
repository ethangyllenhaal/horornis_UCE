#!/bin/bash
fsc26 -t noSmall2Large.tpl -n 100000 -e noSmall2Large.est -M -L 50 -q -c 6 -multiSFS
cat noSmall2Large/*.bestlhoods >> noSmall2Large.txt
for i in $(seq 49)
do
	fsc26 -t noSmall2Large.tpl -n 100000 -e noSmall2Large.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p noSmall2Large/*.bestlhoods >> noSmall2Large.txt
done

