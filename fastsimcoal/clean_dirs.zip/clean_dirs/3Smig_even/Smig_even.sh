#!/bin/bash
fsc26 -t Smig_even.tpl -n 100000 -e Smig_even.est -M -L 50 -q -c 6 -multiSFS
cat Smig_even/*.bestlhoods >> Smig_even.txt
for i in $(seq 49)
do
	fsc26 -t Smig_even.tpl -n 100000 -e Smig_even.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p Smig_even/*.bestlhoods >> Smig_even.txt
done

