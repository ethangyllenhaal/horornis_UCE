#!/bin/bash
fsc26 -t all6.tpl -n 100000 -e all6.est -M -L 50 -q -c 6 -multiSFS
cat all6/*.bestlhoods >> all6.txt
for i in $(seq 49)
do
	fsc26 -t all6.tpl -n 100000 -e all6.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p all6/*.bestlhoods >> all6.txt
done

