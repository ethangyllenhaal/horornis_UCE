#!/bin/bash
fsc26 -t sisters_even.tpl -n 100000 -e sisters_even.est -M -L 50 -q -c 6 -multiSFS
cat sisters_even/*.bestlhoods >> sisters_even.txt
for i in $(seq 49)
do
	fsc26 -t sisters_even.tpl -n 100000 -e sisters_even.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p sisters_even/*.bestlhoods >> sisters_even.txt
done

