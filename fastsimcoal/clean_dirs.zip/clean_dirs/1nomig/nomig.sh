#!/bin/bash
fsc26 -t nomig.tpl -n 100000 -e nomig.est -M -L 50 -q -c 6 -multiSFS
cat nomig/*.bestlhoods >> nomig.txt
for i in $(seq 49)
do
	fsc26 -t nomig.tpl -n 100000 -e nomig.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p nomig/*.bestlhoods >> nomig.txt
done

