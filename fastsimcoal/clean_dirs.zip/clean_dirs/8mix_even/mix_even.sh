#!/bin/bash
fsc26 -t mix_even.tpl -n 100000 -e mix_even.est -M -L 50 -q -c 6 -multiSFS
cat mix_even/*.bestlhoods >> mix_even.txt
for i in $(seq 49)
do
	fsc26 -t mix_even.tpl -n 100000 -e mix_even.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p mix_even/*.bestlhoods >> mix_even.txt
done

