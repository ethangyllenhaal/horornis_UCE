#!/bin/bash
fsc26 -t mix_uneven.tpl -n 100000 -e mix_uneven.est -M -L 50 -q -c 6 -multiSFS
cat mix_uneven/*.bestlhoods >> mix_uneven.txt
for i in $(seq 49)
do
	fsc26 -t mix_uneven.tpl -n 100000 -e mix_uneven.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p mix_uneven/*.bestlhoods >> mix_uneven.txt
done

