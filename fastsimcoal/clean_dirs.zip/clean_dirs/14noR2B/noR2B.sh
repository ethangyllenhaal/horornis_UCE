#!/bin/bash
fsc26 -t noR2B.tpl -n 100000 -e noR2B.est -M -L 50 -q -c 6 -multiSFS
cat noR2B/*.bestlhoods >> noR2B.txt
for i in $(seq 49)
do
	fsc26 -t noR2B.tpl -n 100000 -e noR2B.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p noR2B/*.bestlhoods >> noR2B.txt
done

