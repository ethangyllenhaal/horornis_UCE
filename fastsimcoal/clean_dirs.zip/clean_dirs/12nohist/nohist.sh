#!/bin/bash
fsc26 -t nohist.tpl -n 100000 -e nohist.est -M -L 50 -q -c 6 -multiSFS
cat nohist/*.bestlhoods >> nohist.txt
for i in $(seq 49)
do
	fsc26 -t nohist.tpl -n 100000 -e nohist.est -M -L 50 -q -c 6 -multiSFS
	sed -n 2p nohist/*.bestlhoods >> nohist.txt
done

